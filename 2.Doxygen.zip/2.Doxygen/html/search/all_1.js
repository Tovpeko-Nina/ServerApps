var searchData=
[
  ['createtable_0',['createTable',['../class_data_base.html#a9e75ff25d1ae8b53f7b07efacb513f5a',1,'DataBase']]]
];
