var searchData=
[
  ['database_0',['DataBase',['../class_data_base.html',1,'']]],
  ['databasedestroyer_1',['DatabaseDestroyer',['../class_database_destroyer.html',1,'']]],
  ['dichotomymethod_2',['DichotomyMethod',['../class_dichotomy_method.html',1,'']]]
];
