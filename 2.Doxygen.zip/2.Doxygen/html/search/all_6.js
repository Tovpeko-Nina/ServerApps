var searchData=
[
  ['initialize_0',['initialize',['../class_singltoneforclient_destroyer.html#a7ffa25602937b75adece04da4fff291c',1,'SingltoneforclientDestroyer::initialize()'],['../class_database_destroyer.html#a7286e728135f77ed25f8097962466fc6',1,'DatabaseDestroyer::initialize()']]]
];
