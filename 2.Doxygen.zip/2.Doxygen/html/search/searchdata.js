var indexSectionsWithContent =
{
  0: "acdefgimoqrst~",
  1: "adfgmst",
  2: "st",
  3: "acdefgimoqrst~",
  4: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Friends"
};

