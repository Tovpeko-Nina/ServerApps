var searchData=
[
  ['singltoneforclient_2eh_0',['singltoneforclient.h',['../singltoneforclient_8h.html',1,'']]]
];
