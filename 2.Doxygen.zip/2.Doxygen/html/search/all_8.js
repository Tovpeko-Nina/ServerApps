var searchData=
[
  ['on_5fauth_5fok_0',['on_auth_ok',['../class_functions_for_client.html#a4e33f2b10bcba8be0def5c59127117a1',1,'FunctionsForClient']]],
  ['operator_3d_1',['operator=',['../class_singltoneforclient.html#a5ac67adf47505b61f3086f7fec6853e8',1,'Singltoneforclient']]]
];
