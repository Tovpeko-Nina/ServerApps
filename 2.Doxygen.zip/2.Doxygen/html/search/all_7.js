var searchData=
[
  ['mainwindow_0',['MainWindow',['../class_main_window.html',1,'MainWindow'],['../class_main_window.html#a996c5a2b6f77944776856f08ec30858d',1,'MainWindow::MainWindow()']]],
  ['msgfromserver_1',['msgFromServer',['../class_singltoneforclient.html#a24e88d28cfe36f994f2c1953b3d263b3',1,'Singltoneforclient']]],
  ['msghandler_2',['msgHandler',['../class_functions_for_client.html#a5ff0b6dacc095168d6884efc224af2f3',1,'FunctionsForClient']]]
];
