var searchData=
[
  ['sendauth_0',['sendAuth',['../class_functions_for_client.html#ac302072c9c3a913ded5b9adfe2b40127',1,'FunctionsForClient']]],
  ['sendmsgtoserver_1',['sendMsgToServer',['../class_singltoneforclient.html#a67c2fe0155bdc5201f0cf75b169e955f',1,'Singltoneforclient']]],
  ['sendreg_2',['sendReg',['../class_functions_for_client.html#a9fce12264425c90bc53fd4b89b88c995',1,'FunctionsForClient']]],
  ['sendstat_3',['sendStat',['../class_functions_for_client.html#a1a3544de34ba7d8d9d663f79736ded65',1,'FunctionsForClient']]],
  ['sendtask1_4',['sendTask1',['../class_functions_for_client.html#a0ec4d388722b95cacf992cd86417cd8b',1,'FunctionsForClient']]],
  ['sendtask2_5',['sendTask2',['../class_functions_for_client.html#a0d344887d5c1cb06b1099b04e3456323',1,'FunctionsForClient']]],
  ['sendtask3_6',['sendTask3',['../class_functions_for_client.html#a37e2cc83d1e56a744d7da3198f87bed7',1,'FunctionsForClient']]],
  ['sendtask4_7',['sendTask4',['../class_functions_for_client.html#a9c0ee544aa20f2dfd50e850da3b692ee',1,'FunctionsForClient']]],
  ['sha512_8',['SHA512',['../class_s_h_a512.html',1,'']]],
  ['singltoneforclient_9',['Singltoneforclient',['../class_singltoneforclient.html',1,'Singltoneforclient'],['../class_singltoneforclient.html#afc71dc7a04f3316521d32fa78f9cdb01',1,'Singltoneforclient::Singltoneforclient(QObject *parent=nullptr)'],['../class_singltoneforclient.html#ab18f452d7cf6e914f622f478541970e3',1,'Singltoneforclient::Singltoneforclient(Singltoneforclient &amp;)=delete']]],
  ['singltoneforclient_2eh_10',['singltoneforclient.h',['../singltoneforclient_8h.html',1,'']]],
  ['singltoneforclientdestroyer_11',['SingltoneforclientDestroyer',['../class_singltoneforclient_destroyer.html',1,'']]],
  ['solution_12',['solution',['../class_functions_for_client.html#aec504b8d3d2c93267eef9de4ba815b7a',1,'FunctionsForClient::solution()'],['../class_main_window.html#ae0d43b8d391a3830587de9dd2c1b4a10',1,'MainWindow::solution()']]],
  ['solve_13',['solve',['../class_dichotomy_method.html#a9eb390ee9efc642a3d35af8fdedff9d7',1,'DichotomyMethod']]],
  ['stat_14',['Stat',['../class_main_window.html#abec69731c701c4bf9c63f21825e20996',1,'MainWindow']]]
];
