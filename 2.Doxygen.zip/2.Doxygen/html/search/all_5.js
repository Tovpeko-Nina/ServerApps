var searchData=
[
  ['getdatabase_0',['getDatabase',['../class_data_base.html#a5dfceb41f007b3edd47b9b0862c034be',1,'DataBase']]],
  ['getinstance_1',['getInstance',['../class_singltoneforclient.html#a5b9d02eae1b920a9ec1aa95cd270ad33',1,'Singltoneforclient::getInstance()'],['../class_data_base.html#a9583bc04f915bb5dab6d3cee96bbf970',1,'DataBase::getInstance()']]],
  ['graph_2',['Graph',['../class_graph.html',1,'Graph'],['../class_graph.html#ae4c72b8ac4d693c49800a4c7e273654f',1,'Graph::Graph()']]]
];
